import { editTemplate } from "./editTemplate.js";


let _router = undefined;
 let _renderHandler = undefined;
 let _gamesService = undefined;


 function initialize(router, renderHandler, gamesService){
    _router=router;
    _renderHandler=renderHandler;
    _gamesService=gamesService;
}

async function submitHandler(id,event){

    event.preventDefault();
    let formData = new FormData(event.target);
    let newGame = {
        title: formData.get("title"),
        category: formData.get("category"),
        maxLevel: formData.get("maxLevel"),
        imageUrl: formData.get("imageUrl"),
        summary: formData.get("summary")
    }
    
    await _gamesService.updateItem(newGame,id);
    _router.redirect(`/details/${id}`)
}

async function getView(context, next){

    let gameId = context.params.id;
    let game = await _gamesService.get(gameId);
    console.log(game);

    let model ={
        game,
        submitHandler
    }
    let templateResult = editTemplate(model);
    _renderHandler(templateResult);

    next();
}



export default{
    getView,
    initialize
}