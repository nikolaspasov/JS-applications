import { createTemplate } from "./createTemplate.js";


let _router = undefined;
 let _renderHandler = undefined;
 let _gamesService = undefined;


function initialize(router, renderHandler, gamesService){
    _router=router;
    _renderHandler=renderHandler;
    _gamesService=gamesService;
}

async function submitHandler(event){

    event.preventDefault();
    let formData = new FormData(event.target);
    let newGame = {
        title: formData.get("title"),
        category: formData.get("category"),
        maxLevel: formData.get("maxLevel"),
        imageUrl: formData.get("imageUrl"),
        summary: formData.get("summary")
    }

    await _gamesService.createItem(newGame);
    _router.redirect('/home')
}

async function getView(context, next){


    let model ={
        submitHandler
    }
    let templateResult = createTemplate(model);
    _renderHandler(templateResult);

    
    next();
}



export default{
    getView,
    initialize
}